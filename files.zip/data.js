const familyData = {
  people: [
    // Generation 1 - Grandparents (Paternal)
    { id: 1, name: "Ibrahim Fitwalla", gender: "male", dob: "1938-03-15", deceased: true, photo: null, phone: null },
    { id: 2, name: "Khadija Fitwalla", gender: "female", dob: "1942-07-22", deceased: true, photo: null, phone: null },

    // Generation 1 - Grandparents (Maternal)
    { id: 3, name: "Yusuf Merchant", gender: "male", dob: "1940-11-05", deceased: true, photo: null, phone: null },
    { id: 4, name: "Fatima Merchant", gender: "female", dob: "1944-02-18", deceased: false, photo: null, phone: null },

    // Generation 2 - Parents & Uncles/Aunts (Paternal side)
    { id: 5, name: "Ahmed Fitwalla", gender: "male", dob: "1965-06-10", deceased: false, photo: null, phone: null },
    { id: 6, name: "Zainab Fitwalla", gender: "female", dob: "1968-09-30", deceased: false, photo: null, phone: null },
    { id: 7, name: "Omar Fitwalla", gender: "male", dob: "1967-01-25", deceased: false, photo: null, phone: null },
    { id: 8, name: "Ruqayyah Fitwalla", gender: "female", dob: "1970-04-12", deceased: false, photo: null, phone: null },

    // Generation 2 - Parents & Uncles/Aunts (Maternal side)
    { id: 9, name: "Sara Merchant", gender: "female", dob: "1969-08-03", deceased: false, photo: null, phone: null },
    { id: 10, name: "Bilal Merchant", gender: "male", dob: "1972-12-20", deceased: false, photo: null, phone: null },
    { id: 11, name: "Noor Merchant", gender: "female", dob: "1975-05-14", deceased: false, photo: null, phone: null },

    // Generation 3 - Ammar & Cousins
    { id: 12, name: "Ammar Fitwalla", gender: "male", dob: "1995-04-17", deceased: false, photo: null, phone: null },
    { id: 13, name: "Hana Fitwalla", gender: "female", dob: "1997-11-08", deceased: false, photo: null, phone: null },
    { id: 14, name: "Zaid Fitwalla", gender: "male", dob: "1993-02-28", deceased: false, photo: null, phone: null },
    { id: 15, name: "Layla Fitwalla", gender: "female", dob: "1996-07-19", deceased: false, photo: null, phone: null },
    { id: 16, name: "Yousef Merchant", gender: "male", dob: "1998-03-11", deceased: false, photo: null, phone: null },
    { id: 17, name: "Maryam Merchant", gender: "female", dob: "2000-09-25", deceased: false, photo: null, phone: null },
    { id: 18, name: "Ali Merchant", gender: "male", dob: "1994-06-30", deceased: false, photo: null, phone: null },
  ],

  couples: [
    { id: "c1", person1: 1, person2: 2, married: true },   // Grandparents paternal
    { id: "c2", person1: 3, person2: 4, married: true },   // Grandparents maternal
    { id: "c3", person1: 5, person2: 9, married: true },   // Ammar's parents
    { id: "c4", person1: 7, person2: 8, married: true },   // Uncle Omar
    { id: "c5", person1: 10, person2: 11, married: true }, // Uncle Bilal
  ],

  // parentCouple: which couple are the parents, children: sorted by dob automatically
  families: [
    { parentCouple: "c1", children: [5, 6, 7] },   // Ibrahim & Khadija's kids
    { parentCouple: "c2", children: [9, 10, 11] },  // Yusuf & Fatima's kids
    { parentCouple: "c3", children: [12, 13] },     // Ahmed & Sara's kids (Ammar + Hana)
    { parentCouple: "c4", children: [14, 15] },     // Omar & Ruqayyah's kids
    { parentCouple: "c5", children: [16, 17, 18] }, // Bilal & Noor's kids
  ]
};
